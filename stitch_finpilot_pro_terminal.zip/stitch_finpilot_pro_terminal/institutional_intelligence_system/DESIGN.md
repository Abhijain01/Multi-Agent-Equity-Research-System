---
name: Institutional Intelligence System
colors:
  surface: '#11131b'
  surface-dim: '#11131b'
  surface-bright: '#373942'
  surface-container-lowest: '#0c0e16'
  surface-container-low: '#191b23'
  surface-container: '#1d1f27'
  surface-container-high: '#282a32'
  surface-container-highest: '#32343d'
  on-surface: '#e1e2ed'
  on-surface-variant: '#c3c6d7'
  inverse-surface: '#e1e2ed'
  inverse-on-surface: '#2e3039'
  outline: '#8d90a0'
  outline-variant: '#434655'
  surface-tint: '#b4c5ff'
  primary: '#b4c5ff'
  on-primary: '#002a78'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#0053db'
  secondary: '#b7c8e1'
  on-secondary: '#213145'
  secondary-container: '#3a4a5f'
  on-secondary-container: '#a9bad3'
  tertiary: '#ffb596'
  on-tertiary: '#581e00'
  tertiary-container: '#bc4800'
  on-tertiary-container: '#ffede6'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#d3e4fe'
  secondary-fixed-dim: '#b7c8e1'
  on-secondary-fixed: '#0b1c30'
  on-secondary-fixed-variant: '#38485d'
  tertiary-fixed: '#ffdbcd'
  tertiary-fixed-dim: '#ffb596'
  on-tertiary-fixed: '#360f00'
  on-tertiary-fixed-variant: '#7d2d00'
  background: '#11131b'
  on-background: '#e1e2ed'
  surface-variant: '#32343d'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-lg:
    fontFamily: JetBrains Mono
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
  data-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  data-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 24px
---

## Brand & Style

The design system is engineered for high-stakes institutional equity research, prioritizing data density and cognitive clarity over decorative elements. It occupies the space between legacy financial terminals and modern AI-driven interfaces. The aesthetic is **Corporate Modern with a technical edge**, evoking a sense of "quietly confident" authority. 

The visual language utilizes a "Dark Mode First" philosophy to reduce eye strain during extended analytical sessions. It relies on precision, utilizing 1px borders and a strict 4px grid to create a structured environment where information is the primary focus. The emotional response is one of surgical precision, speed, and institutional reliability.

## Colors

The palette is anchored in a deep navy hierarchy to provide depth without the harshness of pure black. 

- **Base Layers:** The background uses `#0B1326`, with surfaces stepping up in luminosity (`#151F36`, `#1E2943`) to define information architecture.
- **Accents:** A "Confident Blue" (`#2563EB`) is reserved for primary actions, focus states, and active AI processing indicators.
- **Semantics:** Bullish (Emerald), Bearish (Crimson), and Caution (Amber) colors are saturated to ensure immediate recognition against the dark background while maintaining AAA accessibility standards for text overlays.
- **Typography:** Off-white is used for readability, while a muted blue-gray handles meta-data and labels to minimize visual noise.

## Typography

Typography is split by functional role: **Inter** handles all narrative, UI labels, and structural text, while **JetBrains Mono** is strictly reserved for quantitative data.

- **Inter:** Chosen for its high x-height and exceptional legibility in small-scale UI environments. It maintains a professional, neutral tone.
- **JetBrains Mono:** Used for stock tickers, price action, financial ratios, and table data. The monospaced nature ensures that columns of numbers remain perfectly aligned, facilitating faster scanning of financial statements.
- **Hierarchy:** We utilize a tight typographic scale. Large displays are capped to prevent the interface from feeling "airy"—density is a feature here, not a bug.

## Layout & Spacing

The layout employs a **Fluid Grid System** optimized for multi-monitor setups common in institutional trading.

- **Grid:** A 12-column grid system with 16px gutters. In dense data views (e.g., Terminal mode), gutters may be reduced to 8px to maximize screen real estate.
- **Rhythm:** All spacing is a multiple of 4px. Use `md` (16px) for standard container padding and `sm` (8px) for internal element grouping.
- **Responsive Behavior:** 
  - **Desktop:** Sidebars are persistent. Dashboard widgets can be resized or rearranged.
  - **Tablet:** Sidebars collapse into a rail system.
  - **Mobile:** Single-column flow with a bottom-docked navigation bar for quick ticker searching and AI chat access.

## Elevation & Depth

This design system avoids heavy shadows in favor of **Tonal Layering** and **Low-Contrast Outlines**.

- **Surfaces:** Depth is communicated by color. The further "forward" an element is, the lighter its navy fill becomes. 
  - Level 0: `#0B1326` (Background)
  - Level 1: `#151F36` (Cards/Panels)
  - Level 2: `#1E2943` (Modals/Overlays)
- **Borders:** Every container utilizes a 1px solid border (`#2D3A59`). This "Ghost Border" technique defines structure without adding the visual weight of heavy drop shadows.
- **Active States:** Elements being hovered or interacted with may use a subtle outer glow of the primary blue, but the offset is always 0 to maintain the technical, flat aesthetic.

## Shapes

The shape language is **Soft (0.25rem)**. This slight rounding takes the "edge" off the institutional aesthetic, making the platform feel modern and refined rather than dated and brutalist. 

- **Primary Elements:** Buttons, Input fields, and Cards use the base 4px radius.
- **Tags/Chips:** May utilize the `rounded-lg` (8px) setting to differentiate them from actionable buttons.
- **Selections:** Highlighting in tables should be sharp (0px) to align perfectly with grid lines.

## Components

- **Buttons:** Primary buttons are solid Blue (`#2563EB`) with white text. Secondary buttons are Ghost-style with 1px borders. Use `label-caps` for button text to emphasize action.
- **Input Fields:** Dark backgrounds (`#0B1326`) with 1px borders. Focus state changes border color to Primary Blue and adds a 1px inner stroke.
- **Data Tables:** High-density. Rows have a 1px bottom border. Hovering a row triggers a subtle background shift to `#1E2943`. Numbers are always `data-md` (JetBrains Mono) and right-aligned.
- **AI Chat Interface:** Messages are nested in Level 2 surfaces. The AI's "thinking" state is represented by a pulsing 2px border or a minimal progress ring.
- **Live Tickers:** Numbers that change should "flash" their semantic color (green or red) for 300ms before fading back to the primary text color.
- **Charts:** Use a 1.5px line weight for time-series data. Area charts should use a vertical gradient from the primary color to transparent.